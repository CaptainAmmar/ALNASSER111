import * as React from 'react';
import { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  private handleReset = () => {
    window.location.reload();
  };

  public render() {
    const { children } = this.props;
    if (this.state.hasError) {
      let errorMessage = 'حدث خطأ غير متوقع في التطبيق.';
      let errorDetail = this.state.error?.message || '';
      let isFirestoreError = false;

      try {
        if (this.state.error?.message) {
          const parsed = JSON.parse(this.state.error.message);
          if (parsed.error && parsed.operationType) {
            isFirestoreError = true;
            errorMessage = `خطأ في قاعدة البيانات: ${parsed.error}`;
            errorDetail = `Operation: ${parsed.operationType}, Path: ${parsed.path || 'N/A'}`;
          }
        }
      } catch (e) {
        // Not a JSON error
      }

      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-right font-sans" dir="rtl">
          <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col">
            <div className="p-8 text-center space-y-6 flex-1">
              <div className="w-20 h-20 bg-red-100 rounded-2xl flex items-center justify-center mx-auto text-red-600 animate-bounce">
                <AlertTriangle size={40} />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-black text-slate-900">عذراً، حدث خطأ تقني</h2>
                <p className="text-slate-600 leading-relaxed max-w-md mx-auto">
                  واجه التطبيق مشكلة غير متوقعة منعت استمرار العرض. لقد قمنا بتسجيل هذا الخطأ تقنياً.
                </p>
              </div>

              <div className="bg-red-50 rounded-2xl p-6 text-right space-y-3 border border-red-100">
                <div className="flex items-center gap-2 text-red-700 font-bold mb-1">
                  <AlertTriangle size={18} />
                  <span>تفاصيل الخطأ:</span>
                </div>
                <p className="text-red-600 font-mono text-sm break-all bg-white/50 p-3 rounded-xl border border-red-200/50">
                  {errorMessage}
                </p>
                {errorDetail && errorDetail !== errorMessage && (
                  <p className="text-slate-500 font-mono text-xs opacity-75">
                    {errorDetail}
                  </p>
                )}
              </div>
              
              {isFirestoreError && (
                <div className="bg-amber-50 rounded-2xl p-4 text-sm text-amber-800 text-right flex items-start gap-3">
                  <div className="p-2 bg-amber-100 rounded-lg shrink-0">
                    <RefreshCw size={16} />
                  </div>
                  <div className="space-y-1">
                    <p className="font-bold">تلميح للحل:</p>
                    <p className="opacity-90">
                      غالباً ما يكون هذا بسبب ضعف الاتصال بالإنترنت أو تجاوز حصة الاستخدام اليومية. يرجى محاولة تحديث الصفحة.
                    </p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                <button
                  onClick={this.handleReset}
                  className="py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center gap-2"
                >
                  <RefreshCw size={20} />
                  إعادة تحميل التطبيق
                </button>
                <button
                  onClick={() => {
                    const text = `Error: ${errorMessage}\nDetail: ${errorDetail}\nStack: ${this.state.error?.stack}`;
                    navigator.clipboard.writeText(text).then(() => {
                      const btn = document.getElementById('copy-btn');
                      if (btn) {
                        const originalText = btn.innerHTML;
                        btn.innerHTML = 'تم النسخ!';
                        btn.classList.add('bg-emerald-100', 'text-emerald-700');
                        setTimeout(() => {
                          btn.innerHTML = originalText;
                          btn.classList.remove('bg-emerald-100', 'text-emerald-700');
                        }, 2000);
                      }
                    });
                  }}
                  id="copy-btn"
                  className="py-4 bg-slate-100 text-slate-700 rounded-2xl font-bold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
                >
                  نسخ تفاصيل الخطأ
                </button>
              </div>
            </div>
            <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">نظام إدارة وكالة الناصر للملاحة</p>
            </div>
          </div>
        </div>
      );
    }

    return children;
  }
}
