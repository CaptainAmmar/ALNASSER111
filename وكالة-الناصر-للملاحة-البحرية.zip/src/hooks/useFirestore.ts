import { useState, useEffect } from 'react';
import { 
  collection, query, onSnapshot, addDoc, 
  updateDoc, deleteDoc, doc, QueryConstraint, setDoc,
  writeBatch
} from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export function useFirestore<T>(collectionName: string, ...queryConstraints: QueryConstraint[]) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Use a stable key for query constraints to avoid infinite re-renders
  const constraintsKey = queryConstraints.length > 0 
    ? queryConstraints.map(c => typeof c.type === 'string' ? c.type : 'unknown').join(',') 
    : 'none';

  useEffect(() => {
    const q = query(collection(db, collectionName), ...queryConstraints);
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: T[] = snapshot.docs.map(doc => ({
        ...doc.data() as any,
        id: doc.id
      }));
      setData(items);
      setLoading(false);
    }, (err: any) => {
      console.error(`Error fetching ${collectionName}:`, err);
      if (err.code === 'permission-denied') {
        try {
          handleFirestoreError(err, OperationType.LIST, collectionName);
        } catch (e: any) {
          setError(e.message);
        }
      } else {
        setError(err.message);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [collectionName, constraintsKey]);

  const add = async (item: Omit<T, 'id'>) => {
    try {
      const docRef = await addDoc(collection(db, collectionName), item);
      return docRef.id;
    } catch (err: any) {
      console.error(`Error adding to ${collectionName}:`, err);
      if (err.code === 'resource-exhausted') {
        setError('تم تجاوز حصة الاستخدام اليومية لقاعدة البيانات. يرجى المحاولة لاحقاً.');
      } else if (err.code === 'permission-denied') {
        handleFirestoreError(err, OperationType.CREATE, collectionName);
      }
      throw err;
    }
  };

  const addBatch = async (items: Omit<T, 'id'>[]) => {
    if (items.length === 0) return;
    const batch = writeBatch(db);
    const colRef = collection(db, collectionName);
    
    items.forEach(item => {
      const docRef = doc(colRef);
      batch.set(docRef, item);
    });

    try {
      await batch.commit();
    } catch (err: any) {
      console.error(`Error adding batch to ${collectionName}:`, err);
      if (err.code === 'resource-exhausted') {
        setError('تم تجاوز حصة الاستخدام اليومية لقاعدة البيانات. يرجى المحاولة لاحقاً.');
      } else if (err.code === 'permission-denied') {
        handleFirestoreError(err, OperationType.WRITE, collectionName);
      }
      throw err;
    }
  };

  const update = async (id: string, item: Partial<T>) => {
    try {
      const docRef = doc(db, collectionName, id);
      await updateDoc(docRef, item as any);
    } catch (err: any) {
      console.error(`Error updating ${collectionName}:`, err);
      if (err.code === 'resource-exhausted') {
        setError('تم تجاوز حصة الاستخدام اليومية لقاعدة البيانات. يرجى المحاولة لاحقاً.');
      } else if (err.code === 'permission-denied') {
        handleFirestoreError(err, OperationType.UPDATE, `${collectionName}/${id}`);
      }
      throw err;
    }
  };

  const remove = async (id: string) => {
    try {
      const docRef = doc(db, collectionName, id);
      await deleteDoc(docRef);
    } catch (err: any) {
      console.error(`Error deleting from ${collectionName}:`, err);
      if (err.code === 'resource-exhausted') {
        setError('تم تجاوز حصة الاستخدام اليومية لقاعدة البيانات. يرجى المحاولة لاحقاً.');
      } else if (err.code === 'permission-denied') {
        handleFirestoreError(err, OperationType.DELETE, `${collectionName}/${id}`);
      }
      throw err;
    }
  };

  const set = async (id: string, item: T) => {
    try {
      const docRef = doc(db, collectionName, id);
      await setDoc(docRef, item as any);
    } catch (err: any) {
      console.error(`Error setting ${collectionName}/${id}:`, err);
      if (err.code === 'resource-exhausted') {
        setError('تم تجاوز حصة الاستخدام اليومية لقاعدة البيانات. يرجى المحاولة لاحقاً.');
      } else if (err.code === 'permission-denied') {
        handleFirestoreError(err, OperationType.WRITE, `${collectionName}/${id}`);
      }
      throw err;
    }
  };

  return { data, loading, error, add, addBatch, update, remove, set };
}
